export { OrderManagementPage } from './components/OrderManagementPage';
